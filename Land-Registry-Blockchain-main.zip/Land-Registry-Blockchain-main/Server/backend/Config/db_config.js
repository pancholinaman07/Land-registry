module.exports = {
  email: "EMAIL",
  password: "PASSWORD",
  NEXMO_API_KEY: "API_KEY",
  NEXMO_API_SECRET: "SECRET_KEY",
  NEXMO_FROM_NUMBER: "NUMBER",
  MongoURI: "mongodb+srv://admin:admin@cluster0.jvlcb.mongodb.net/test?retryWrites=true&w=majority"
}
